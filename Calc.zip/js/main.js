let app = new Vue({
    el: '#app',
    data: {
        zp: '',
        mrp: 3063,
        mzp: 60000,
        mrp14: 42882,
        mrp25: 76575,
        result: '',
        jsonData: '',
        selected: '',
        pickedMzp: '',
        pickedRezident: ''
    },

    methods: {
        async getJson() {
            const responce = await fetch("main.json");
            if (responce.ok) {
                const jsonData = await responce.json();
                this.jsonData = jsonData;
            } else {
                alert("Ошибка при соединении с сервером");
            }
        },

        calc: function () {
            if (this.selected == 'ТОО на ОУР' &&
                this.pickedMzp == 'Без вычета МЗП' &&
                this.pickedRezident == 'Резидент') {
                let opv = this.zp * 0.1;
                console.log(this.zp * 0.1)
            }
            // let opv = this.zp * 0.1;
            // console.log(opv);
            // let vosms = this.zp * 0.02;
            // console.log(vosms);
            // let kor90 = (this.zp - opv - vosms) * 0.9;
            // console.log(kor90);
            // let ipn = Math.floor((this.zp - opv - kor90 - 0 - vosms) * 0.1);
            // console.log(ipn);
            // let oosms = this.zp * 0.03;
            // console.log(oosms);
            // let so = this.mzp * 0.035;
            // console.log(so);
            // let sn = Math.floor(this.mrp14 * 0.095 - so);
            // console.log(sn);
            // this.result = Math.floor(+this.zp - ipn - opv - vosms) + ' тенге';
            // console.log(this.selected);
            // console.log(this.pickedMzp);
            // console.log(this.pickedRezident);
            // console.log(this.pickedRezident.name)

            for (let key in this.pickedRezident) {
                if (this.pickedRezident.name == "Резидент") {
                    for (let key in this.pickedRezident.koef) {
                        this.pickedRezident.koef[key];
                    let opv = this.zp * this.pickedRezident.koef.opv;
                    let vosms = this.zp * this.pickedRezident.koef.vosms;
                    let kor90 = (this.zp - opv - vosms) * this.pickedRezident.koef.kor90;
                    let ipn = Math.floor((this.zp - opv - kor90 - 0 - vosms) * this.pickedRezident.koef.opv);
                    let oosms = this.zp * this.pickedRezident.koef.oosms;
                    let so = this.mzp * this.pickedRezident.koef.so;
                    let sn = Math.floor(this.mrp14 * 0.095 - so);
                    this.result = Math.floor(+this.zp - ipn - opv - vosms) + ' тенге';
                    }
                } 

                if (this.pickedRezident.name == "Не резидент") {
                    for (let key in this.pickedRezident.koef) {
                        this.pickedRezident.koef[key];
                    let opv = this.zp * this.pickedRezident.koef.opv;
                    let vosms = this.zp * this.pickedRezident.koef.vosms;
                    let kor90 = (this.zp - opv - vosms) * this.pickedRezident.koef.kor90;
                    let ipn = Math.floor(this.zp * this.pickedRezident.koef.opv);
                    let oosms = this.zp * this.pickedRezident.koef.oosms;
                    let so = this.mzp * this.pickedRezident.koef.so;
                    let sn = Math.floor(this.mrp14 * 0.095 - so);
                    this.result = Math.floor(+this.zp - ipn - opv - vosms) + ' тенге';
                    }
                }
            }
        }
    },

    async mounted() {
        await this.getJson();
    }
})